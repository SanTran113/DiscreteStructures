
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;


public class Calculator {

    public static LinkedList_ add(LinkedList_ num1, LinkedList_ num2) {
        int gNum = 0;
        LinkedList_ finalNode = new LinkedList_();
        Node node1 = num1.getTop();
        Node node2 = num2.getTop();
        int remainder = 0;
        int temp = 0;


        if (node1.getSpot() > node2.getSpot()) {
            gNum = num1.getCount();
        } else {
            gNum = num2.getCount();
        }

        for (int i = gNum; i > 0; i--) {

            int add1 = 0;
            int add2 = 0;

            if (node1 != null) {
                add1 = node1.getValue();
                node1 = node1.getRest();
            }
            if (node2 != null) { // if i want to work backwards

                add2 = node2.getValue();
                node2 = node2.getRest();
            }

            // carry
            temp = add1 + add2 + remainder;
            remainder = 0;
            if (temp >= 10 && i != 1) {
                remainder = Math.floorDiv(temp, 10);
                temp = temp % 10;
            }
            finalNode.push(temp);
        }


        if(Integer.toString(finalNode.getTop().getValue()).length() > 1) {
            String t = Integer.toString(finalNode.getTop().getValue());
            finalNode.pop();
        for (int n = t.length() - 1; n >= 0; n--) {
            finalNode.push(Integer.parseInt(String.valueOf(t.charAt(n))));
        }
    }
        return finalNode;

}


    public static LinkedList_ multiply(LinkedList_ num1, LinkedList_ num2) {
        int gNum = 0;
        int remainder = 0;
        LinkedList_ maxList;
        LinkedList_ minList;
        Node node1 = num1.getTop();
        Node node2 = num2.getTop();
        LinkedList_ firstRow = new LinkedList_();

        int temp = 0;
        int count = 0;
        LinkedList_ secondRow = new LinkedList_();      //



        if (node1.getSpot() > node2.getSpot()) {
            gNum = num1.getCount();
            maxList = num1;
            minList = num2;
        } else {
            gNum = num2.getCount();
            maxList = num2;
            minList = num1;
        }

        Node minNode = minList.getTop();
        Node maxNode = maxList.getTop();



        while (minNode != null) {
            maxNode = maxList.getTop();      // every i is every node
            secondRow = new LinkedList_();


            for (int j = 0; j < count; j ++) {
                secondRow.push(0);
            }

            while (maxNode != null) {       //what we are multiplying against
                temp = (minNode.getValue() * maxNode.getValue()) + remainder;
                remainder = 0;
                if (temp >= 10 && maxNode.getSpot() != 1) { //carry
                    remainder = Math.floorDiv(temp, 10);
                    temp = temp % 10;
                }

                if (minNode.getSpot() == minList.getCount()) { // after first iteration
                    firstRow.push(temp);
                }
                else  {
                    secondRow.push(temp);
                }
//                final_.add(temp);
                    maxNode = maxNode.getRest();
            }

            count += 1;

            if (firstRow.getTop() != null && secondRow.getTop() != null) {
                firstRow = reverseLinkedList(firstRow);
                secondRow = reverseLinkedList(secondRow);
                firstRow = add(firstRow, secondRow);
            }
            minNode = minNode.getRest();
        }

        return firstRow;
    }


    public static LinkedList_ reverseLinkedList(LinkedList_ list) {
        LinkedList_ newList = new LinkedList_();
        Node nodeList = list.getTop();
        List<Integer> testList = new ArrayList<>();

        while (nodeList != null) {
            testList.add(nodeList.getValue());
            nodeList = nodeList.getRest();
        }

        for (int k = 0; k < testList.size(); k++) {
            newList.push(testList.get(k));
        }

        return newList;
    }
}